import { useState } from 'react'
// import He

import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <h1 className=' align-middle bg-green-600  p-4 font-bold '>React Router</h1>
    </>
  )
}

export default App
