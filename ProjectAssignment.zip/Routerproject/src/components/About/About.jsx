import React from 'react'

export default function About() {
    return (
      <div className="py-16 bg-white">
        <h1>Contact US</h1>
      </div>
    );
}